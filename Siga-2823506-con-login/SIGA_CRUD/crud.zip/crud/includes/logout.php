<h1>Bienvenido al panel de logout</h1>
<p>Este es el contenido de la página de logout.</p>
