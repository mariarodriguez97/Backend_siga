<h1>Bienvenido al panel de inicio</h1>
<p>Este es el contenido de la página de inicio.</p>
