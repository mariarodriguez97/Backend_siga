<h1>Bienvenido al panel de acudientes</h1>
<p>Este es el contenido de la página de acudientes.</p>
